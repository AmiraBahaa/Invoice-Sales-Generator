/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Amira Bahaa
 */

package controller;

import model.Header;
import model.HeaderTableModel;
import model.Line;
import model.LineTableModel;
import view.MainForm;
import view.addNewInvoice;
import view.addItem;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

public class ActionListeners implements ActionListener {
    private MainForm form;
    private addNewInvoice HeaderAdding;
    private addItem LineAdding;

    public ActionListeners() {
    }
    public ActionListeners(MainForm form) {
        this.form = form;
    }
    public ActionListeners(addNewInvoice DialogHeader, addItem DialgoLine) {
        this.HeaderAdding = DialogHeader;
        this.LineAdding = DialgoLine;
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
          
            case "AddHeader OK":
                OkHeader();
                break;
            case "AddHeader Cancel":
                addHeaderCancel();
                break;
            case "AddLine OK":
                addLineOK();
                break;
                
            case "Load File":
                loadFile();
                break;
            case "Save File":
                FileSaving();
                break;
            case "Create New Invoice":
                addNewInvoice();
                break;
         
            case "AddLine Cancel":
                addLineCancel();
                break;
                   
            case "Delete Invoice":
                deleteInvoice();
                break;
            case "New Line":
                addInvoiceItem();
                break;
            case "Delete Line":
                deleteInvoiceItem();
                break;
        }
    }
    private void loadFile() {
        JFileChooser fileChooser = new JFileChooser();
        try {
            int outcome = fileChooser.showOpenDialog(form);
            if (outcome == JFileChooser.APPROVE_OPTION) {
//for the header
                File fileHead = fileChooser.getSelectedFile();
                Path pathHead = Paths.get(fileHead.getAbsolutePath());
                List<String> items = Files.readAllLines(pathHead);
                ArrayList<Header> invoiceItems = new ArrayList<>();
                for (String headerLine : items) {
                    String[] itemsArray = headerLine.split(",");
                    String x1 = itemsArray[0];
                    String x2 = itemsArray[1];
                    String x3 = itemsArray[2];
                    int iid = Integer.parseInt(x1);
                    Date dateFormat = MainForm.dateFormat.parse(x2);
                    Header head = new Header(iid, x3, dateFormat);
                    invoiceItems.add(head);
                }
                
                
                
                form.setArrayOfHeaders(invoiceItems);
                
                outcome = fileChooser.showOpenDialog(form);
               
                
                
                if (outcome == JFileChooser.APPROVE_OPTION) {
                    //for the line
                    File fileLine = fileChooser.getSelectedFile();
                    Path pathLine = Paths.get(fileLine.getAbsolutePath());
                    List<String> linesOfLine = Files.readAllLines(pathLine);
                    for (String lineOfLine : linesOfLine) {
                        String[] arr = lineOfLine.split(",");
                        String str1 = arr[0];
                        String str2 = arr[1];
                        String str3 = arr[2];
                        String str4 = arr[3];
                        int invCode = Integer.parseInt(str1);
                        double price = Double.parseDouble(str3);
                        int count = Integer.parseInt(str4);
                        Header inv = form.getObject(invCode);
                        Line line = new Line(inv, str2, price, count);
                        inv.getLines().add(line);
                    }
                    
                    //test
                System.out.println("Start Files Reading ..");
                System.out.println("Header File..");
                System.out.println(invoiceItems);
                System.out.println("Line File..");
                for (String lineOfLine : linesOfLine){
                System.out.println(lineOfLine);
                }
                System.out.println("End Files Reading ...");
                }
                HeaderTableModel headerTableModel = new HeaderTableModel(invoiceItems);
                form.setHeaderTableModel(headerTableModel);
                form.getHeadersTable().setModel(headerTableModel);  
            }
        }
        
        //exception handlers
        catch (IOException ex) {
            JOptionPane.showMessageDialog(form, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (ParseException ex) {
            JOptionPane.showMessageDialog(form, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        catch (ArrayIndexOutOfBoundsException ex){
            JOptionPane.showMessageDialog(form, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        catch(NullPointerException ex) {
            JOptionPane.showMessageDialog(form, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void FileSaving() {
        ArrayList<Header> invoicesArray = form.getArrayOfHeaders();
        JFileChooser fileChooser = new JFileChooser();
        try {
            int outcome = fileChooser.showSaveDialog(form);
            if (outcome == JFileChooser.APPROVE_OPTION) {
                File fileHead = fileChooser.getSelectedFile();
                FileWriter FwriteHeader = new FileWriter(fileHead);
                String head = "";
                String lines = "";
                for (Header header : invoicesArray) {
                    head += header.toString();
                    head += "\n";
                    for (Line line : header.getLines()) {
                        lines += line.toString();
                        lines += "\n";
                    }
                }
                head = head.substring(0, head.length()-1);
                lines = lines.substring(0, lines.length()-1);
                outcome = fileChooser.showSaveDialog(form);
                File lineFile = fileChooser.getSelectedFile();
                FileWriter lineWriter = new FileWriter(lineFile);
                FwriteHeader.write(head);
                lineWriter.write(lines);
                FwriteHeader.close();
                lineWriter.close();
            }
        }    //exception handlers IOException
        catch (IOException ex) {
            JOptionPane.showMessageDialog(form, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    } 
    private void addNewInvoice() {
        HeaderAdding = new addNewInvoice(form);
        HeaderAdding.setVisible(true);
    }
    private void deleteInvoice() {
        int selectedInvoiceIndex = form.getHeadersTable().getSelectedRow();
        if (selectedInvoiceIndex != -1) {
            form.getArrayOfHeaders().remove(selectedInvoiceIndex);
            form.getHeaderTableModel().fireTableDataChanged();
            form.getLinesTable().setModel(new LineTableModel(null));
            form.setArrOfLines(null);
            form.getCustomerNameLabel().setText("");
            form.getInvoiceNumberLabel().setText("");
            form.getInvoiceTotalLabel().setText("");
            form.getInvoiceDateLabel().setText("");
        }
    }
    private void addInvoiceItem() {
        LineAdding = new addItem(form);
        LineAdding.setVisible(true);  
    }
    private void deleteInvoiceItem() {
        int lineIndex = form.getLinesTable().getSelectedRow();
        int invoiceIndex = form.getHeadersTable().getSelectedRow();
        if (lineIndex != -1) {
            form.getArrOfLines().remove(lineIndex);
            LineTableModel lineTableModel = (LineTableModel) form.getLinesTable().getModel();
            lineTableModel.fireTableDataChanged();
            form.getInvoiceTotalLabel().setText("" + form.getArrayOfHeaders().get(invoiceIndex).getTotal());
            form.getHeaderTableModel().fireTableDataChanged();
            form.getHeadersTable().setRowSelectionInterval(invoiceIndex, invoiceIndex);
        }
    } 
    private void addHeaderCancel() {
        HeaderAdding.setVisible(false);
        HeaderAdding.dispose();
        HeaderAdding = null;
    }
    private void OkHeader() {
        try
        {
        HeaderAdding.setVisible(false);
        String customer = HeaderAdding.getCustomerField().getText();
        String date = HeaderAdding.getDateField().getText();
        Date newDate = new Date();
        try {
            newDate = MainForm.dateFormat.parse(date);
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(form, "Cannot parse date, resetting to today.", "Invalid date format", JOptionPane.ERROR_MESSAGE);
        }
        int number = 0;
        for (Header i : form.getArrayOfHeaders()) {
            if (i.getHeaderNo() > number) {
                number = i.getHeaderNo();
            }
        }
        number++;
        
        Header invoiceGenerator = new Header(number, customer, newDate);
        form.getArrayOfHeaders().add(invoiceGenerator);
        form.getHeaderTableModel().fireTableDataChanged();
        HeaderAdding.dispose();
        HeaderAdding = null;
        }
        
           //exception handlers
        catch (NullPointerException ex){
            JOptionPane.showMessageDialog(form, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void addLineCancel() {
        LineAdding.setVisible(false);
        LineAdding.dispose();
        LineAdding = null;
    }
    private void addLineOK() {
        try {
        LineAdding.setVisible(false);
        String name = LineAdding.getItemName().getText();
        String s1 = LineAdding.getItemCount().getText();
        String s2 = LineAdding.getItemCost().getText();
        int c = 1;
        double cost = 1;
        try {
            c = Integer.parseInt(s1);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(form, "Can't convert number", "Invalid number format", JOptionPane.ERROR_MESSAGE);
        }
        try {
            cost = Double.parseDouble(s2);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(form, "Can't convert price", "Invalid number format", JOptionPane.ERROR_MESSAGE);
        }
        int invoiceHeaderSelected = form.getHeadersTable().getSelectedRow();
        if (invoiceHeaderSelected != -1) {
            Header invoiceHeader = form.getArrayOfHeaders().get(invoiceHeaderSelected);
            Line newline = new Line(invoiceHeader,name, cost, c);
            
            form.getArrOfLines().add(newline);
            LineTableModel lineTableModel = (LineTableModel) form.getLinesTable().getModel();
            lineTableModel.fireTableDataChanged();
            form.getHeaderTableModel().fireTableDataChanged();
        }
        form.getHeadersTable().setRowSelectionInterval(invoiceHeaderSelected, invoiceHeaderSelected);
        LineAdding.dispose();
        LineAdding = null;
        }
           //exception handler for IllegalArgumentException
        
        catch (IllegalArgumentException ex){
            JOptionPane.showMessageDialog(form, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
