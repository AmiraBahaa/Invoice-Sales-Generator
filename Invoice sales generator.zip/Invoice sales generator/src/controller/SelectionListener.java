/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Amira Bahaa
 */

package controller;

import model.Header;
import model.Line;
import model.LineTableModel;
import view.MainForm;
import java.util.ArrayList;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class SelectionListener implements ListSelectionListener {
    private MainForm form;
    public SelectionListener(MainForm form) {
        this.form = form;
    }

    @Override
    public void valueChanged(ListSelectionEvent e) {
        int invoiceIndex = form.getHeadersTable().getSelectedRow();
        
        if (invoiceIndex != -1)
        
        {
            Header invoiceSelected = form.getArrayOfHeaders().get(invoiceIndex);
            ArrayList<Line> lines = invoiceSelected.getLines();
            LineTableModel lineTableModel = new LineTableModel(lines);
            form.setArrOfLines(lines);
            form.getLinesTable().setModel(lineTableModel);

            form.getInvoiceDateLabel().setText(MainForm.dateFormat.format(invoiceSelected.getDate())); 
            form.getCustomerNameLabel().setText(invoiceSelected.getCustomerHeadr());
            
            form.getInvoiceNumberLabel().setText("" + invoiceSelected.getHeaderNo());
            form.getInvoiceTotalLabel().setText("" + invoiceSelected.getTotal());
        }
    }

}
