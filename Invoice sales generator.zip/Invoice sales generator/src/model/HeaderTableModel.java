/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Amira Bahaa
 */

package model;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;
import view.MainForm;

public class HeaderTableModel extends AbstractTableModel {
    private ArrayList<Header> arrayOfHeaders;
    private String[] headerTable = {"number", "Date", "Customer", "Total"};

    public HeaderTableModel(ArrayList<Header> headersArray) {
        this.arrayOfHeaders = headersArray;
    }
      @Override
    public int getColumnCount() {
        return headerTable.length;
    }
    @Override
    public int getRowCount() {
        return arrayOfHeaders.size();
    }
  
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Header header = arrayOfHeaders.get(rowIndex);
        switch (columnIndex) {
            case 0 -> {return header.getHeaderNo();}
            case 1 -> {return MainForm.dateFormat.format(header.getDate());}
            case 2 -> {return header.getCustomerHeadr();}
            case 3 -> {return header.getTotal();}
        }
        return null;
    }
    @Override
    public String getColumnName(int header) {
        return headerTable[header];
    }
}
