/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Amira Bahaa
 */

package model;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Header {
    private int headerNo;
    private String customerHeadr;
    private Date date;
    private ArrayList<Line> lines;
    private DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
    
//empty constructor
    public Header() {
    }

    public Header(int num, String custHeader, Date date) {
        this.headerNo = num;
        this.customerHeadr = custHeader;
        this.date = date;
    }
//create getters and setters

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public int getHeaderNo() {
        return headerNo;
    }

    public void setHeaderNo(int headerNo) {
        this.headerNo = headerNo;
    }

    public String getCustomerHeadr() {
        return customerHeadr;
    }

    public void setCustomerHeadr(String customerHeadr) {
        this.customerHeadr = customerHeadr;
    }

    public ArrayList<Line> getLines() {
        if (lines == null) {
            lines = new ArrayList<>();
        }
        return lines;
    }

    public void setLines(ArrayList<Line> lines) {
        this.lines = lines;
    }
    
    public double getTotal() {
        double result = 0.0;
        for (int c = 0; c < getLines().size(); c++) {
            result += getLines().get(c).result();
        }
        
        return result;
    }
//outputs the result in the tostring method
    @Override
    public String toString() {
        return headerNo + "," + dateFormat.format(date) + "," + customerHeadr;
    }
    
}
