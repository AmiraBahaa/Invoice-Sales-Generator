/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Amira Bahaa
 */

package model;

public class Line {
    private Header newheader;
     private double itemPrice;
    private String item;
    private int itemCounting;

    //creat constructors one emoty and other with the parameters
    public Line() {
    }

    public Line(Header head, String item, double linePrice, int lineCount) {
        this.newheader = head;
        this.item = item;
        this.itemPrice = linePrice;
        this.itemCounting = lineCount;
    }

    public double getItemPrice() {
        return itemPrice;
    }

    public void setItemPrice(double itemPrice) {
        this.itemPrice = itemPrice;
    }
    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }
  public Header getNewheader() {
        return newheader;
    }

    public void setNewheader(Header newheader) {
        this.newheader = newheader;
    }

 
    public int getItemCounting() {
        return itemCounting;
    }

    public void setItemCounting(int itemCounting) {
        this.itemCounting = itemCounting;
    }
    
    public double result() {
        return itemPrice * itemCounting;
    }

    @Override
    public String toString() {
        return newheader.getHeaderNo() + "and " + item + "and " + itemPrice + "and " + itemCounting;
    }
}
