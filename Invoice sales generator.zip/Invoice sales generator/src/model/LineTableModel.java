/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Amira Bahaa
 */

package model;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

public class LineTableModel extends AbstractTableModel {

    private ArrayList<Line> arrayOfLines;
    private String[] headerTable = {"Item ", "Price", "Count", "Item Total"};

    public LineTableModel(ArrayList<Line> linesArray) {
        this.arrayOfLines = linesArray;
    }
    @Override
    public int getRowCount() {
        return arrayOfLines == null ? 0 : arrayOfLines.size();
    }
    @Override
    public int getColumnCount() {
        return headerTable.length;
    }
    @Override
    public Object getValueAt(int row, int col) {
        if (arrayOfLines == null) {
            return null;
        } else {
            Line lines = arrayOfLines.get(row);
            return switch (col) 
            {
                case 0 -> lines.getItem();
                case 1 -> lines.getItemPrice();
                case 2 -> lines.getItemCounting();
                case 3 -> lines.result();
                default -> null;
            };
        }
    }
    @Override
    public String getColumnName(int column) {
        return headerTable[column];
    }

}
